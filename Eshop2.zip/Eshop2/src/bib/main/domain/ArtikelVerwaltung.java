package bib.main.domain;

import java.io.IOException;

import bib.main.domain.exceptions.ArtikelExistiertSchonException;
import bib.main.entities.ArtikelListe;
import bib.main.pm.FilePersistenceManager;
import bib.main.pm.PersistenceManager;
import bib.main.entities.Artikel;

public class ArtikelVerwaltung {

	private ArtikelListe artikelBestand = new ArtikelListe();
	private PersistenceManager pm = new FilePersistenceManager();
	

	public void liesDaten(String datei) throws IOException {
		pm.openForReading(datei);

		Artikel einArtikel;
		do {
			einArtikel = pm.ladeArtikel();
			if (einArtikel != null) {
				try {
					einfuegen(einArtikel);
				} catch (ArtikelExistiertSchonException e1) {
					//nichts
				}
			}
		} while (einArtikel != null);

		pm.close();
	}


	public void einfuegen(Artikel einArtikel) throws ArtikelExistiertSchonException {
		if (artikelBestand.enthaelt(einArtikel)) {
			throw new ArtikelExistiertSchonException(einArtikel, " - in 'einfuegen()'");
		}

		artikelBestand.einfuegen(einArtikel);
	}


	public void loeschen(Artikel einArtikel) {
		artikelBestand = artikelBestand.loeschen(einArtikel);
	}

	public ArtikelListe sucheArtikel(String bezeichnung) {
		ArtikelListe suchErg = new ArtikelListe();
		ArtikelListe aktArtikelListenElt = artikelBestand;
		while (aktArtikelListenElt != null) {
			Artikel aktArtikel = aktArtikelListenElt.gibErstenArtikel();
			if (aktArtikel.getBezeichnung().equals(bezeichnung)) {
				suchErg.einfuegen(aktArtikel);
			}
			aktArtikelListenElt = aktArtikelListenElt.gibRestlicheArtikel();
		}
		return suchErg;
	}

	public ArtikelListe getArtikelBestand() {
		return new ArtikelListe(artikelBestand);
	}
	

}
