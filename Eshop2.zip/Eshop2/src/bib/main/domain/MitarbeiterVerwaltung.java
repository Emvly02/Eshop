package bib.main.domain;

import bib.main.entities.Mitarbeiter;
import bib.main.entities.MitarbeiterListe;
import bib.main.pm.FilePersistenceManager;
import bib.main.pm.PersistenceManager;

public class MitarbeiterVerwaltung {


    private MitarbeiterListe mitarbeiterListe = new MitarbeiterListe();
    private PersistenceManager pm = new FilePersistenceManager();

    public void einfuegen(Mitarbeiter einMitarbeiter){
        try{
            if (mitarbeiterListe.enthaelt(einMitarbeiter)) {
                mitarbeiterListe.einfuegen(einMitarbeiter);
            }
        }
        catch(Exception e){
            System.out.println("Fehler bei Mitarbeiter-Registrierung");
        }

    }

    public void loeschen(Mitarbeiter einMitarbeiter) {
        // das übernimmt die BuchListe:
        mitarbeiterListe = mitarbeiterListe.loeschen(einMitarbeiter);
    }


    public MitarbeiterListe sucheMitarbeiter(int nr) {
        MitarbeiterListe suchErg = new MitarbeiterListe();
        MitarbeiterListe aktMitarbeiterListenElt = mitarbeiterListe;
        while (aktMitarbeiterListenElt != null) {
            Mitarbeiter aktMitarbeiter = aktMitarbeiterListenElt.gibErstenMitarbeiter();
            if (aktMitarbeiter.getId() == nr) {
                suchErg.einfuegen(aktMitarbeiter);
            }
            aktMitarbeiterListenElt = aktMitarbeiterListenElt.gibRestlicheMitarbeiter();
        }
        return suchErg;
    }

    public MitarbeiterListe getMitarbeiterListe() {
        return new MitarbeiterListe(mitarbeiterListe);
    }




}




