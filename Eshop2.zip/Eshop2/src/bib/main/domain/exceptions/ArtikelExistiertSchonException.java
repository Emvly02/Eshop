package bib.main.domain.exceptions;

import bib.main.entities.Artikel;

/**
 * Exception zur Signalisierung, dass ein Buch bereits existiert (z.B. bei einem Einfügevorgang).
 * 
 * @author teschke
 */
public class ArtikelExistiertSchonException extends Exception {

	private Artikel artikel;
	
	/**
	 * Konstruktor
	 * 
	 * @param artikel Das bereits existierende Buch
	 * @param zusatzMsg zusätzlicher Text für die Fehlermeldung
	 */
	public ArtikelExistiertSchonException(Artikel artikel, String zusatzMsg) {
		super("Buch mit Titel " + artikel.getBezeichnung() + " und Nummer " + artikel.getArtikelNr()
				+ " existiert bereits" + zusatzMsg);
		this.artikel = artikel;
	}

	public Artikel getBuch() {
		return artikel;
	}
}
