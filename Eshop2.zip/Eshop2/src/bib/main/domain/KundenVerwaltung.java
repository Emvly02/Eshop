package bib.main.domain;

import bib.main.entities.Artikel;
import bib.main.entities.ArtikelListe;
import bib.main.entities.Kunde;
import bib.main.entities.KundenListe;

public class KundenVerwaltung {

    private KundenListe Kundenbestand = new KundenListe();
    private Kunde eingeloggterKunde;


    public void registrierung(String vorname, String nachname, String adresse, int id, String passwort){
        Kundenbestand.kundeEinfuegen(new Kunde(vorname, nachname, adresse, id, passwort));

    }

    //public Kunde einloggen(String benutzername, String passwort) {


    //}

    public void kundeEinfuegen(Kunde einKunde){
        try{
            if (Kundenbestand.kundenlisteEnthaelt(einKunde)) {
                Kundenbestand.kundeEinfuegen(einKunde);
            }
        }
        catch(Exception e){
            System.out.println("Fehler bei Mitarbeiter-Registrierung");
        }
    }

    public KundenListe sucheKunde(int id) {
        KundenListe suchKu = new KundenListe();
        KundenListe aktKundeListenElt = Kundenbestand;
        while (aktKundeListenElt != null) {
            Kunde aktKunde = aktKundeListenElt.gibErstenKunden();
            if (aktKunde.getId() == id) {
                suchKu.kundeEinfuegen(aktKunde);
            }
            aktKundeListenElt = aktKundeListenElt.gibRestlicheKunden();
        }
        return suchKu;
    }



}
