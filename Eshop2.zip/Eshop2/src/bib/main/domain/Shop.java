package bib.main.domain;

import bib.main.domain.exceptions.ArtikelExistiertSchonException;
import bib.main.entities.*;
import bib.main.ui.CUI.ShopCUI;

import java.util.List;
import java.util.Optional;

public class Shop {
	private String datei = "";
	private ArtikelVerwaltung artikelVW;
	private MitarbeiterVerwaltung mitarbeiterVW;
	private KundenVerwaltung kundenVW;


	public Shop(String datei){

		artikelVW = new ArtikelVerwaltung();
		kundenVW = new KundenVerwaltung();
		mitarbeiterVW = new MitarbeiterVerwaltung();
	}

	public ArtikelListe gibAlleArtikel() {
		return artikelVW.getArtikelBestand();
	}

	public ArtikelListe sucheNachArtikel(String artikel) {
		return artikelVW.sucheArtikel(artikel);
	}

	public Artikel fuegeArtikelEin(String bezeichnung, int artikelNr) throws ArtikelExistiertSchonException {
		Artikel a = new Artikel(bezeichnung, artikelNr);
		artikelVW.einfuegen(a);
		return a;
	}

	public void loescheArtikel(String bezeichnung, int artikelNr) {
		Artikel a = new Artikel(bezeichnung, artikelNr);
		artikelVW.loeschen(a);
	}

	public Kunde fuegeKundeEin(String vorname, String nachname, String adresse, int id, String passwort){
		Kunde k = new Kunde(vorname, nachname, adresse, id, passwort);
		kundenVW.kundeEinfuegen(k);
		return k;
	}

	/*public static Mitarbeiter einloggen(int gesuchteID) {

	}

	public boolean einloggen(String benutzername, String passwort) {

	}

	 */


}
