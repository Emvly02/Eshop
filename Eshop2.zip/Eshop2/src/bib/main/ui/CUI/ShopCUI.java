package bib.main.ui.CUI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import bib.main.domain.exceptions.ArtikelExistiertSchonException;
import bib.main.domain.Shop;
import bib.main.entities.Artikel;
import bib.main.entities.ArtikelListe;

public class ShopCUI {

	private Shop eshop;
	private BufferedReader in;
	
	public ShopCUI(String datei) throws IOException {

		eshop = new Shop(datei);
		in = new BufferedReader(new InputStreamReader(System.in));
	}


	private String liesEingabe() throws IOException {
		return in.readLine();
	}


	private void verarbeiteEingabe(String line) throws IOException {
		String bezeichnung;
		int artikelNr;
		int id;
		ArtikelListe artikelListe;

		switch (line) {
		case "a": //alle Artikel
			artikelListe = eshop.gibAlleArtikel();
			gibArtikellisteAus(artikelListe);
			break;

		case "d": //delete
			System.out.print("Artikelbezeichnung: ");
			bezeichnung = liesEingabe();

			System.out.println("Artikelnummer: ");
			artikelNr = Integer.parseInt(liesEingabe());

			//Verfuegbarkeit auf false setzen

			eshop.loescheArtikel(bezeichnung, artikelNr);
			break;

		case "e": //einfügen
			System.out.print("Artikelbezeichnung: ");
			bezeichnung = liesEingabe();

			System.out.println("Artikelnummer: ");
			artikelNr = Integer.parseInt(liesEingabe());

			System.out.print("ID-Nummer: ");
			id = Integer.parseInt(liesEingabe());

			try {
				eshop.fuegeArtikelEin(bezeichnung, artikelNr);
				System.out.println("Einfügen ok");
				//Verfuegbarkeit auf true setzen, falls false
			} catch (ArtikelExistiertSchonException e) {
				System.out.println("Fehler beim Einfügen");
				e.printStackTrace();
			}
			break;

		case "f": //Artikel finden
			System.out.print("Artikelbezeichnung: ");
			bezeichnung = liesEingabe();
			artikelListe = eshop.sucheNachArtikel(bezeichnung);
			gibArtikellisteAus(artikelListe);
			break;

			case "r":
				System.out.println("Bitte geben sie ihren Vornamen ein:");
				String vorname = liesEingabe();
				System.out.println("Bitte geben sie ihren Nachnamen ein:");
				String nachname = liesEingabe();
				System.out.println("Bitte geben sie ihre Adresse ein:");
				String adresse = liesEingabe();
				System.out.println("Bitte wählen sie eine ID-Nummer:");
				int idNr = Integer.parseInt(liesEingabe());
				System.out.println("Bitte wählen sie ein Passwort:");
				String passwort = liesEingabe();
				eshop.fuegeKundeEin(vorname, nachname, adresse, idNr, passwort);
				break;

			case "l":
				System.out.println("Bitte geben sie ihren Benutzernamen ein (VornameNachname)");
				String benutzername = liesEingabe();
				System.out.println("Bitte geben sie ihr Passwort ein");
				String passw = liesEingabe();

				break;


			case "m":
				System.out.println("Bitte geben sie ihre ID-Nummer ein");
				int idNu = Integer.parseInt(liesEingabe());

				break;

			case "exit":
				System.exit(0);
				System.out.println("Vielen Dank für Ihren Besuch!");
				break;

		}
	}

	private void gibArtikellisteAus(ArtikelListe liste) {
		System.out.print(liste);
	}

	public void run() {
		String input = ""; 

		do {
			menue();
			try {
				input = liesEingabe();
				verarbeiteEingabe(input);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} while (!input.equals("q"));
	}


	public static void main(String[] args) {
		ShopCUI cui;
		try {
			cui = new ShopCUI("ESHOP");
			cui.run();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public void menue() {
		System.out.println("Wilkommen in unserem Eshop!");
		System.out.println("Um sich als Kunde zu registrieren, drücken sie r");
		System.out.println("Um sich als Kunde anzumelden, drücken sie l");
		System.out.println("Um sich als Mitarbeiter anzumelden, drücken sie m");
		System.out.println("Um alle Artikel zu sehen, drücken sie a");			//Kunde?
		System.out.println("Um einen Artikel zu entfernen drücken sie, d");        //Mitarbeiter
		System.out.println("Um einen neuen Artikel hinzuzufügen, drücken sie e"); //Mitarbeiter
		System.out.println("Um einen Artikel zu finden, drücken sie f");		//Kunde
		System.out.println("Um den Shop zu verlassen, schreiben sie exit");
	}
}
