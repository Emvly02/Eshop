package bib.main.entities;

public class Artikel {

	private String bezeichnung;
	private int artikelNr;
	private boolean verfuegbar;
	private int bestand;



	public Artikel(String bezeichnung, int nr) {
		this.bezeichnung = bezeichnung;
		this.artikelNr = nr;
		this.verfuegbar = true;
		this.bestand = 0;
	}


	public String toString() {
		String verfuegbarkeit = verfuegbar ? "verfuegbar" : "ausverkauft";
		return ("ArtikelNr: " + artikelNr + " / Bezeichnung: " + bezeichnung + " / " + verfuegbarkeit);
	}

	public boolean equals(Object andererArtikel) {
		if (andererArtikel instanceof Artikel)
			return ((this.artikelNr == ((Artikel) andererArtikel).artikelNr)
					&& (this.bezeichnung.equals(((Artikel) andererArtikel).bezeichnung)));
		else
			return false;
	}

	

	
	public int getArtikelNr() {
		return artikelNr;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public boolean istVerfuegbar() {
		return verfuegbar;
	}
}
