package bib.main.entities;

public class ArtikelListe {
	private Artikel artikel = null;
	private ArtikelListe next = null;
	

	public ArtikelListe() {

	}
	

	public ArtikelListe(ArtikelListe original) {
		while (original != null) {
			Artikel artikel = original.gibErstenArtikel();
			if (artikel != null) {
				this.einfuegen(artikel);
				original = original.gibRestlicheArtikel();
			} 
		}
	}
	

	public Artikel gibErstenArtikel() {
		return artikel;
	}

	public ArtikelListe gibRestlicheArtikel() {
		return next;
	}


	public void einfuegen(Artikel einArtikel) {
		if (artikel == null) {
			artikel = einArtikel;
		}
		else {
			if (next == null) {
				next = new ArtikelListe();
			}
			next.einfuegen(einArtikel);
		}
	}	

	public boolean enthaelt(Artikel anderenArtikel) {
		if (this.artikel != null && this.artikel.equals(anderenArtikel)) {
			return true;
		} else {
			if (this.next != null) {
				return this.next.enthaelt(anderenArtikel);
			}
		}
		return false;
	}


	public ArtikelListe loeschen(Artikel artikel) {
		if (this.artikel == null) {
			return this;
		}
		
		if (this.artikel.equals(artikel)) {
			return next;
		} else {
			if (next != null) {
				next = next.loeschen(artikel);
			} 
			return this;
		}
	}


}
