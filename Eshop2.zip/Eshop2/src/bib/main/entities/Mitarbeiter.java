package bib.main.entities;

public class Mitarbeiter extends Benutzer {
    public Mitarbeiter(String vorname, String nachname, String addresse, int id) {
        super(vorname, nachname, addresse, id);
    }

    public String toString2(){
        return String.format("%s: %s, %s, %s", vorname, nachname, addresse, String.valueOf(id));
    }

    public boolean equals(Object andererMitarbeiter) {
        if (andererMitarbeiter instanceof Mitarbeiter) {
            return ((this.id == ((Mitarbeiter) andererMitarbeiter).id)
                    && (this.vorname.equals(((Mitarbeiter) andererMitarbeiter).vorname)));
        }
        else {
            return false;
        }
    }



    public String getNachname() {
        return nachname;
    }


    public String getVorname() {
        return vorname;
    }


}
