package bib.main.entities;

public class KundenListe {
    private Kunde kunde = null;
    private KundenListe next = null;


    public KundenListe() {

    }


    public KundenListe(KundenListe original) {
        while (original != null) {
            Kunde kunde = original.gibErstenKunden();
            if (kunde != null) {
                this.kundeEinfuegen(kunde);
                original = original.gibRestlicheKunden();
            }
        }
    }


    public Kunde gibErstenKunden() {
        return kunde;
    }

    public KundenListe gibRestlicheKunden() {
        return next;
    }


    public void kundeEinfuegen(Kunde einKunde) {
        if (kunde == null) {
            kunde = einKunde;
        }
        else {
            if (next == null) {
                next = new KundenListe();
            }
            next.kundeEinfuegen(einKunde);
        }
    }

    public boolean kundenlisteEnthaelt(Kunde anderenKunden) {
        if (this.kunde != null && this.kunde.equals(anderenKunden)) {
            return true;
        } else {
            if (this.next != null) {
                return this.next.kundenlisteEnthaelt(anderenKunden);
            }
        }
        return false;
    }






}
