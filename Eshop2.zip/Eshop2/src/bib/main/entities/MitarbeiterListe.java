package bib.main.entities;

public class MitarbeiterListe {
	private Mitarbeiter mitarbeiter = null;
	private MitarbeiterListe next = null;

	public MitarbeiterListe() {
	}

	public MitarbeiterListe(MitarbeiterListe original) {
		while (original != null) {
			Mitarbeiter mitarbeiter = original.gibErstenMitarbeiter();
			if (mitarbeiter != null) {
				this.einfuegen(mitarbeiter);
				original = original.gibRestlicheMitarbeiter();
			} 
		}
	}

	public Mitarbeiter gibErstenMitarbeiter() {
		return mitarbeiter;
	}

	public MitarbeiterListe gibRestlicheMitarbeiter() {
		return next;
	}


	public void einfuegen(Mitarbeiter einMitarbeiter) {
		if (mitarbeiter == null) {
			mitarbeiter = einMitarbeiter;
		}
		else {
			if (next == null) {
				next = new MitarbeiterListe();
			}
			next.einfuegen(einMitarbeiter);
		}
	}	

	public boolean enthaelt(Mitarbeiter andererMitarbeiter) {
		if (this.mitarbeiter != null && this.mitarbeiter.equals(andererMitarbeiter)) {
			return true;
		} else {
			if (this.next != null) {
				return this.next.enthaelt(andererMitarbeiter);
			}
		}
		return false;
	}


	public MitarbeiterListe loeschen(Mitarbeiter mitarbeiter) {
		if (this.mitarbeiter == null) {
			return this;
		}
		
		if (this.mitarbeiter.equals(mitarbeiter)) {
			return next;
		} else {
			if (next != null) {
				next = next.loeschen(mitarbeiter);
			} 
			return this;
		}
	}




}
