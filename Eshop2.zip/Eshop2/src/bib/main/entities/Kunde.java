package bib.main.entities;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Kunde extends Benutzer {

	 /*
        ATTRIBUTE: (Name, Nummer), Adresse
        Können sich über Benutzerkennung und Passwort einloggen
        Können sich selbst als Kunde registrieren
        Können mehrere! Artikel in ihren Warenkorb legen
        Können stückzahl der Artikel im Warenkorb ändern
        Können den Warenkorb leeren

        Können Artikel im Warenkorb kaufen
        -> Danach wird Warenkorb geleert & Artikel werden aus dem Bestand genommen
        -> Dann wird eine Rechnung erzeugt und auf dem Bildschirm ausgegeben (nicht hier oder)
     */

	private String passwort;
	private String benutzerName;
	private ArrayList<Artikel> Warenkorb = new ArrayList<Artikel>();

	public Kunde(String vorname, String nachname, String addresse, int ID, String passwort) {
		super(vorname, nachname, addresse, ID);
		this.passwort = passwort;
		this.benutzerName = vorname + nachname;
	}

	public String getPasswort() {
		return this.passwort;
	}

	public void artikelHinzufügen(Artikel artikel){
		Warenkorb.add(artikel);
	}

	public String getBenutzerName() {
		return benutzerName;
	}
}
